<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Tim Kreatif PMB UAD</title>
    <!-- Favicon -->
    <?php if(\App\Models\Setting::get('site_logo')): ?>
        <link rel="icon" href="<?php echo e(asset('storage/' . \App\Models\Setting::get('site_logo'))); ?>">
    <?php else: ?>
        <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>">
    <?php endif; ?>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Alpine.js -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="bg-slate-100 text-slate-800 antialiased flex" x-data="{ sidebarOpen: false }">

    <!-- Sidebar Backdrop Overlay -->
    <div class="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-20 md:hidden"
         x-show="sidebarOpen"
         @click="sidebarOpen = false"
         x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="opacity-0"
         x-transition:enter-end="opacity-100"
         x-transition:leave="transition ease-in duration-200"
         x-transition:leave-start="opacity-100"
         x-transition:leave-end="opacity-0"
         style="display: none;">
    </div>

    <!-- Sidebar -->
    <aside class="w-64 bg-slate-900 text-white h-screen flex flex-col fixed md:sticky md:top-0 z-30 overflow-y-auto transition-transform duration-300 transform md:translate-x-0" id="sidebar" :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">
        <div class="p-6 flex items-center justify-between">
            <span class="text-xl font-bold tracking-tight text-white">Tim Kreatif Admin</span>
            <button class="md:hidden text-slate-400 hover:text-white text-lg" @click="sidebarOpen = false">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <nav class="flex-1 px-4 space-y-2 mt-4">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-slate-800 transition-colors <?php echo e(request()->routeIs('admin.dashboard') ? 'bg-blue-600 text-white' : 'text-slate-300'); ?>">
                <i class="fas fa-home w-5"></i> Dashboard
            </a>
            <?php if(auth()->user()->role === 'admin'): ?>
            <a href="<?php echo e(route('admin.divisions.index')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-slate-800 transition-colors <?php echo e(request()->routeIs('admin.divisions.*') ? 'bg-blue-600 text-white' : 'text-slate-300'); ?>">
                <i class="fas fa-layer-group w-5"></i> Divisi
            </a>
            <a href="<?php echo e(route('admin.periods.index')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-slate-800 transition-colors <?php echo e(request()->routeIs('admin.periods.*') ? 'bg-blue-600 text-white' : 'text-slate-300'); ?>">
                <i class="fas fa-calendar-alt w-5"></i> Periode
            </a>
            <a href="<?php echo e(route('admin.members.index')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-slate-800 transition-colors <?php echo e(request()->routeIs('admin.members.*') ? 'bg-blue-600 text-white' : 'text-slate-300'); ?>">
                <i class="fas fa-users w-5"></i> Anggota
            </a>
            <a href="<?php echo e(route('admin.admission-leaders.index')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-slate-800 transition-colors <?php echo e(request()->routeIs('admin.admission-leaders.*') ? 'bg-blue-600 text-white' : 'text-slate-300'); ?>">
                <i class="fas fa-user-tie w-5"></i> Pimpinan Admisi
            </a>
            <a href="<?php echo e(route('admin.events.index')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-slate-800 transition-colors <?php echo e(request()->routeIs('admin.events.*') ? 'bg-blue-600 text-white' : 'text-slate-300'); ?>">
                <i class="fas fa-calendar-check w-5"></i> Kegiatan
            </a>
            <a href="<?php echo e(route('admin.categories.index')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-slate-800 transition-colors <?php echo e(request()->routeIs('admin.categories.*') ? 'bg-blue-600 text-white' : 'text-slate-300'); ?>">
                <i class="fas fa-tags w-5"></i> Kategori Kegiatan
            </a>
            <a href="<?php echo e(route('admin.news.index')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-slate-800 transition-colors <?php echo e(request()->routeIs('admin.news.*') ? 'bg-blue-600 text-white' : 'text-slate-300'); ?>">
                <i class="fas fa-newspaper w-5"></i> Berita
            </a>
            <?php endif; ?>

            <?php if(auth()->user()->role === 'anggota'): ?>
            <a href="<?php echo e(route('admin.works.index')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-slate-800 transition-colors <?php echo e(request()->routeIs('admin.works.*') ? 'bg-blue-600 text-white' : 'text-slate-300'); ?>">
                <i class="fas fa-briefcase w-5"></i> Karya / Portofolio
            </a>
            <?php endif; ?>

            <?php if(auth()->user()->role === 'admin'): ?>
            <a href="<?php echo e(route('admin.metrics.index')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-slate-800 transition-colors <?php echo e(request()->routeIs('admin.metrics.*') ? 'bg-blue-600 text-white' : 'text-slate-300'); ?>">
                <i class="fas fa-chart-line w-5"></i> Statistik & Metrik
            </a>
            <a href="<?php echo e(route('admin.instagram-posts.index')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-slate-800 transition-colors <?php echo e(request()->routeIs('admin.instagram-posts.*') ? 'bg-blue-600 text-white' : 'text-slate-300'); ?>">
                <i class="fab fa-instagram w-5 text-pink-500"></i> Laporan Instagram
            </a>
            <a href="<?php echo e(route('admin.tiktok-posts.index')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-slate-800 transition-colors <?php echo e(request()->routeIs('admin.tiktok-posts.*') ? 'bg-blue-600 text-white' : 'text-slate-300'); ?>">
                <i class="fab fa-tiktok w-5 text-slate-100"></i> Laporan TikTok
            </a>
            <a href="<?php echo e(route('admin.settings.index')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-slate-800 transition-colors <?php echo e(request()->routeIs('admin.settings.*') ? 'bg-blue-600 text-white' : 'text-slate-300'); ?>">
                <i class="fas fa-cog w-5"></i> Pengaturan
            </a>
            <?php endif; ?>
        </nav>
        <div class="p-4 border-t border-slate-700">
            <a href="<?php echo e(route('admin.account.edit')); ?>" class="flex items-center gap-3 px-4 py-2 text-slate-300 hover:text-white transition-colors">
                <i class="fas fa-user-circle w-5"></i> Akun Saya
            </a>
            <form action="<?php echo e(route('logout')); ?>" method="POST" class="mt-2">
                <?php echo csrf_field(); ?>
                <button type="submit" class="flex items-center gap-3 px-4 py-2 w-full text-left text-red-400 hover:text-red-300 hover:bg-slate-800 rounded-lg transition-colors">
                    <i class="fas fa-sign-out-alt w-5"></i> Logout
                </button>
            </form>
        </div>
    </aside>

    <!-- Main Content -->
    <div class="flex-1 min-w-0 flex flex-col min-h-screen relative w-full overflow-x-hidden md:w-auto">
        <!-- Top Navbar for Mobile -->
        <header class="bg-white shadow-sm md:hidden p-4 flex justify-between items-center z-10">
            <div class="flex items-center gap-2">
                <button @click="sidebarOpen = !sidebarOpen" class="text-slate-600 hover:text-blue-600 focus:outline-none text-2xl">
                    <i class="fas fa-bars"></i>
                </button>
                <span class="font-bold text-lg text-slate-800">Admin Panel</span>
            </div>
        </header>

        <!-- Content Area -->
        <main class="flex-1 p-4 md:p-8 overflow-y-auto min-w-0">
            <?php if(session('success')): ?>
            <div class="mb-6 bg-green-50 border-l-4 border-green-500 p-4 rounded shadow-sm flex items-start gap-3" x-data="{ show: true }" x-show="show">
                <i class="fas fa-check-circle text-green-500 mt-1"></i>
                <div class="flex-1">
                    <p class="text-green-800 font-medium"><?php echo e(session('success')); ?></p>
                </div>
                <button @click="show = false" class="text-green-600 hover:text-green-800"><i class="fas fa-times"></i></button>
            </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
            <div class="mb-6 bg-red-50 border-l-4 border-red-500 p-4 rounded shadow-sm flex items-start gap-3" x-data="{ show: true }" x-show="show">
                <i class="fas fa-exclamation-circle text-red-500 mt-1"></i>
                <div class="flex-1">
                    <p class="text-red-800 font-medium"><?php echo e(session('error')); ?></p>
                </div>
                <button @click="show = false" class="text-red-600 hover:text-red-800"><i class="fas fa-times"></i></button>
            </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // SweetAlert2 Delete Confirmation
            const deleteForms = document.querySelectorAll('form[onsubmit*="return confirm"]');
            deleteForms.forEach(form => {
                const originalOnsubmit = form.getAttribute('onsubmit');
                // Extract message from confirm('...') if possible
                let message = "Data ini tidak bisa dikembalikan!";
                const match = originalOnsubmit.match(/confirm\(['"](.*?)['"]\)/);
                if (match && match[1]) {
                    message = match[1];
                }
                
                form.removeAttribute('onsubmit');
                form.addEventListener('submit', function(e) {
                    e.preventDefault();
                    Swal.fire({
                        title: 'Apakah Anda Yakin?',
                        text: message,
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#ef4444', // red-500
                        cancelButtonColor: '#64748b', // slate-500
                        confirmButtonText: 'Ya, hapus!',
                        cancelButtonText: 'Batal'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            form.submit();
                        }
                    });
                });
            });
        });
    </script>
</body>
</html>
<?php /**PATH R:\Code\website_profile_tim_kreatif_pmb_uad\resources\views/layouts/admin.blade.php ENDPATH**/ ?>