<?php $__env->startSection('content'); ?>
<div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <h1 class="text-2xl md:text-3xl font-bold text-slate-800">Kategori Kegiatan</h1>
    <a href="<?php echo e(route('admin.categories.create')); ?>" class="w-full sm:w-auto text-center px-4 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-sm font-semibold text-sm">
        <i class="fas fa-plus mr-2"></i> Tambah Kategori
    </a>
</div>

<div class="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse whitespace-nowrap">
            <thead>
                <tr class="bg-slate-50 border-b border-slate-100 text-slate-500 text-sm uppercase tracking-wider">
                    <th class="px-3 py-3 md:p-4 font-semibold text-sm">Nama Kategori</th>
                    <th class="px-3 py-3 md:p-4 font-semibold text-sm">Warna Label</th>
                    <th class="px-3 py-3 md:p-4 font-semibold text-sm text-right">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-slate-50 transition-colors">
                    <td class="px-3 py-3 md:p-4">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-800 border border-slate-200">
                            <span class="w-2 h-2 rounded-full mr-1.5" style="background-color: <?php echo e($category->color); ?>"></span>
                            <?php echo e($category->name); ?>

                        </span>
                    <td class="px-3 py-3 md:p-4">
                        <div class="flex items-center text-slate-600">
                            <div class="w-6 h-6 rounded border border-slate-200 mr-2 shadow-sm" style="background-color: <?php echo e($category->color); ?>"></div>
                            <span class="text-sm font-mono"><?php echo e($category->color); ?></span>
                        </div>
                    </td>
                    <td class="px-3 py-3 md:p-4 text-right">
                        <div class="flex justify-end space-x-2">
                            <a href="<?php echo e(route('admin.categories.edit', $category)); ?>" class="p-2 text-blue-600 hover:bg-blue-50 rounded transition-colors" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('admin.categories.destroy', $category)); ?>" method="POST" class="inline-block" onsubmit="return confirm('Yakin ingin menghapus kategori ini?');">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="p-2 text-red-600 hover:bg-red-50 rounded transition-colors" title="Hapus">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="p-8 text-center text-slate-500">
                        <i class="fas fa-tags text-4xl mb-3 text-slate-300"></i>
                        <p>Belum ada kategori kegiatan yang ditambahkan.</p>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH R:\Code\website_profile_tim_kreatif_pmb_uad\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>