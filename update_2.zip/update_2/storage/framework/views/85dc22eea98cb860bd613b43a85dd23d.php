<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <h1 class="text-3xl font-bold text-slate-800">Manajemen Pimpinan Admisi</h1>
    <a href="<?php echo e(route('admin.admission-leaders.create')); ?>" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"><i class="fas fa-plus mr-2"></i> Tambah Pimpinan</a>
</div>

<div class="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse whitespace-nowrap">
            <thead>
                <tr class="bg-slate-50 border-b border-slate-100">
                    <th class="p-4 font-medium text-slate-600">ID</th>
                    <th class="p-4 font-medium text-slate-600">Foto</th>
                    <th class="p-4 font-medium text-slate-600">Nama Lengkap</th>
                    <th class="p-4 font-medium text-slate-600">Jabatan</th>
                    <th class="p-4 font-medium text-slate-600">Urutan Tampilan</th>
                    <th class="p-4 font-medium text-slate-600 text-right">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $leaders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leader): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                    <td class="p-4 text-slate-600"><?php echo e($loop->iteration); ?></td>
                    <td class="p-4">
                        <?php if($leader->photo): ?>
                            <img src="<?php echo e(asset('storage/'.$leader->photo)); ?>" class="w-10 h-10 rounded-lg object-cover">
                        <?php else: ?>
                            <div class="w-10 h-10 rounded-lg bg-slate-200 flex items-center justify-center text-slate-500"><i class="fas fa-user-tie"></i></div>
                        <?php endif; ?>
                    </td>
                    <td class="p-4 font-bold text-slate-800"><?php echo e($leader->name); ?></td>
                    <td class="p-4 text-slate-600"><?php echo e($leader->position); ?></td>
                    <td class="p-4 text-slate-600"><?php echo e($leader->order); ?></td>
                    <td class="p-4 text-right space-x-2">
                        <a href="<?php echo e(route('admin.admission-leaders.edit', $leader->id)); ?>" class="text-blue-500 hover:text-blue-700"><i class="fas fa-edit"></i></a>
                        <form action="<?php echo e(route('admin.admission-leaders.destroy', $leader->id)); ?>" method="POST" class="inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus pimpinan ini?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="text-red-500 hover:text-red-700"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="p-8 text-center text-slate-500">Belum ada data pimpinan admisi.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH R:\Code\website_profile_tim_kreatif_pmb_uad\resources\views/admin/admission_leaders/index.blade.php ENDPATH**/ ?>