<?php $__env->startSection('content'); ?>
<div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <h1 class="text-2xl md:text-3xl font-bold text-slate-800">Manajemen Divisi</h1>
    <a href="<?php echo e(route('admin.divisions.create')); ?>" class="w-full sm:w-auto text-center px-4 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-sm font-semibold text-sm">
        <i class="fas fa-plus mr-2"></i> Tambah Divisi
    </a>
</div>

<div class="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse">
            <thead>
                <tr class="bg-slate-50 border-b border-slate-100">
                    <th class="px-3 py-3 md:p-4 font-semibold text-slate-600 text-sm">ID</th>
                    <th class="px-3 py-3 md:p-4 font-semibold text-slate-600 text-sm">Nama Divisi</th>
                    <th class="px-3 py-3 md:p-4 font-semibold text-slate-600 text-sm">Warna Legend</th>
                    <th class="px-3 py-3 md:p-4 font-semibold text-slate-600 text-sm text-right">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                    <td class="px-3 py-3 md:p-4 text-slate-600 text-sm whitespace-nowrap"><?php echo e($loop->iteration); ?></td>
                    <td class="px-3 py-3 md:p-4 font-bold text-slate-800 text-sm"><?php echo e($division->name); ?></td>
                    <td class="px-3 py-3 md:p-4 text-sm">
                        <div class="flex items-center gap-2 whitespace-nowrap">
                            <div class="w-5 h-5 rounded-full border border-slate-200" style="background-color: <?php echo e($division->color_hex); ?>"></div>
                            <span class="text-slate-600 font-mono"><?php echo e($division->color_hex); ?></span>
                        </div>
                    </td>
                    <td class="px-3 py-3 md:p-4 text-right space-x-2 text-sm whitespace-nowrap">
                        <a href="<?php echo e(route('admin.divisions.edit', $division)); ?>" class="text-blue-500 hover:text-blue-700 inline-block"><i class="fas fa-edit"></i></a>
                        <form action="<?php echo e(route('admin.divisions.destroy', $division)); ?>" method="POST" class="inline-block" onsubmit="return confirm('Yakin ingin menghapus?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="text-red-500 hover:text-red-700"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="p-8 text-center text-slate-500">Belum ada data divisi.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH R:\Code\website_profile_tim_kreatif_pmb_uad\resources\views/admin/divisions/index.blade.php ENDPATH**/ ?>