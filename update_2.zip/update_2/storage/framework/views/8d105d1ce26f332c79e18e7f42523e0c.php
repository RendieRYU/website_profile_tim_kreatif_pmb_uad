<?php $__env->startSection('content'); ?>
<h1 class="text-3xl font-bold text-slate-800 mb-6">Pengaturan Akun</h1>

<div class="bg-white rounded-xl shadow-sm border border-slate-100 p-6 max-w-2xl">
    <form action="<?php echo e(route('admin.account.update')); ?>" method="POST">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        
        <div class="mb-4">
            <label class="block text-sm font-medium text-slate-700 mb-1">Username</label>
            <input type="text" name="username" value="<?php echo e($user->username); ?>" class="w-full p-2 border border-slate-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" required>
        </div>
        
        <hr class="my-6 border-slate-200">
        
        <h2 class="text-lg font-bold text-slate-800 mb-4">Ganti Password (Opsional)</h2>
        <p class="text-sm text-slate-500 mb-4">Kosongkan jika tidak ingin mengubah password.</p>
        
        <div class="mb-4">
            <label class="block text-sm font-medium text-slate-700 mb-1">Password Saat Ini (Wajib)</label>
            <input type="password" name="current_password" class="w-full p-2 border border-slate-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" required>
            <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-500 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-4">
            <label class="block text-sm font-medium text-slate-700 mb-1">Password Baru (Opsional)</label>
            <input type="password" name="password" class="w-full p-2 border border-slate-300 rounded-lg focus:ring-blue-500 focus:border-blue-500">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-500 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="mb-6">
            <label class="block text-sm font-medium text-slate-700 mb-1">Konfirmasi Password Baru</label>
            <input type="password" name="password_confirmation" class="w-full p-2 border border-slate-300 rounded-lg focus:ring-blue-500 focus:border-blue-500">
        </div>
        
        <div>
            <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">Simpan Perubahan</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH R:\Code\website_profile_tim_kreatif_pmb_uad\resources\views/admin/account/edit.blade.php ENDPATH**/ ?>