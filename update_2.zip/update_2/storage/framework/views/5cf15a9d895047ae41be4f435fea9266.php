<?php $__env->startSection('content'); ?>
<div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <h1 class="text-2xl md:text-3xl font-bold text-slate-800">Manajemen Kegiatan</h1>
    <div class="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto">
        <a href="<?php echo e(route('admin.events.export')); ?>" class="w-full sm:w-auto px-4 py-2.5 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2 text-sm font-semibold shadow-sm">
            <i class="fas fa-file-excel"></i> Ekspor Excel
        </a>
        <a href="<?php echo e(route('admin.events.create')); ?>" class="w-full sm:w-auto px-4 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 text-sm font-semibold shadow-sm">
            <i class="fas fa-plus"></i> Tambah Kegiatan
        </a>
    </div>
</div>

<div class="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse whitespace-nowrap">
            <thead>
                <tr class="bg-slate-50 border-b border-slate-100">
                    <th class="px-3 py-3 md:p-4 font-semibold text-slate-600 text-sm">ID</th>
                    <th class="px-3 py-3 md:p-4 font-semibold text-slate-600 text-sm">Judul Kegiatan</th>
                    <th class="px-3 py-3 md:p-4 font-semibold text-slate-600 text-sm">Tanggal</th>
                    <th class="px-3 py-3 md:p-4 font-semibold text-slate-600 text-sm">Petugas</th>
                    <th class="px-3 py-3 md:p-4 font-semibold text-slate-600 text-sm text-right">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                    <td class="px-3 py-3 md:p-4 text-slate-600 text-sm"><?php echo e($events->firstItem() + $loop->index); ?></td>
                    <td class="px-3 py-3 md:p-4 font-bold text-slate-800 text-sm"><?php echo e($event->title); ?></td>
                    <td class="px-3 py-3 md:p-4 text-slate-600 text-sm">
                        <i class="far fa-calendar-alt mr-1"></i> <?php echo e($event->event_date->format('d M Y')); ?><br>
                        <i class="far fa-clock mr-1 text-slate-400"></i> <?php echo e($event->event_time ? $event->event_time->format('H:i') : '-'); ?>

                    </td>
                    <td class="px-3 py-3 md:p-4 text-slate-600 text-sm">
                        <span class="px-2 py-1 bg-slate-100 rounded-lg text-xs"><?php echo e($event->members->count()); ?> Anggota</span>
                    </td>
                    <td class="px-3 py-3 md:p-4 text-right space-x-2 text-sm">
                        <a href="<?php echo e(route('admin.events.edit', $event)); ?>" class="text-blue-500 hover:text-blue-700 inline-block"><i class="fas fa-edit"></i></a>
                        <form action="<?php echo e(route('admin.events.destroy', $event)); ?>" method="POST" class="inline-block" onsubmit="return confirm('Yakin ingin menghapus?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="text-red-500 hover:text-red-700"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="p-8 text-center text-slate-500">Belum ada data kegiatan.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="p-4 border-t border-slate-100">
        <?php echo e($events->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH R:\Code\website_profile_tim_kreatif_pmb_uad\resources\views/admin/events/index.blade.php ENDPATH**/ ?>